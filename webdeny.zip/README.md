# WebDeny

A browser extension to increase productivity but still allow access to blocked websites when needed. Instead of blocking the websites at the click of a button, it will unblock them. This will allow you *n* minutes to browse freely, in which it will automatically block again after the time runs out.